<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script src="site/js/jquery_002.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-param" content="_csrf-frontend">
    <meta name="csrf-token" content="NFlGbzFUZTBCNC8XQCYof1A.FidCJTN1VxshNVgiCXIMEi1aSwsCcg==">
    <title>Happy</title>
    <link href="<?php echo e(asset('site/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('site/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('site/css/site.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('site/css/owl.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('site/css/owl_002.css')); ?>" rel="stylesheet">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<section class="main-section">
    <header class="header">
        <div class="navbar navbar-inverse nav-blue navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="/"><img src="<?php echo e(asset('site/img/logo.png')); ?>" class="img-responsive"></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <nav id="w0" class="navbar-fixed-top navbar" role="navigation">
                        <div class="container">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse"
                                        data-target="#w0-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="/">
                                    <img src="<?php echo e(asset('site/img/logo.png')); ?>" alt="Happy Date">
                                </a>
                            </div>
                            <div id="w0-collapse" class="collapse navbar-collapse">
                                <ul id="w1" class="nav navbar-nav navbar-right blue-bg">
                                    <li class="active"><a href="http://guptaclinic.in/dating/frontend/site/index">Acceuil</a>
                                    </li>
                                    <li><a href="http://guptaclinic.in/dating/frontend/site/profile">Profile</a></li>
                                    <li><a href="http://guptaclinic.in/dating/frontend/site/stories">Stories</a></li>
                                    <li><a href="http://guptaclinic.in/dating/frontend/site/blog">Blog</a></li>
                                    <li><a href="http://guptaclinic.in/dating/frontend/site/about">About</a></li>
                                    <li><a href="http://guptaclinic.in/dating/frontend/site/contact">Contact</a></li>
                                    <?php if(auth()->guard()->guest()): ?>
                                        <li><a href="<?php echo e(url('register')); ?>">Signup</a></li>
                                        <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(url('profile')); ?>/<?php echo e(Auth::id()); ?>/edit">Profile</a></li>
                                        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a></li>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                              style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </nav>
                    <!--<ul class="nav navbar-nav navbar-right blue-bg">
                    <li class="active"><a href="index.html">Home</a> </li>
                    <li><a href="profiles.html">Profile</a> </li>
                    <li><a href="stories.html">Stories</a> </li>
                    <li><a href="blog.html">Blog</a> </li>
                    <li><a href="about-us.html">About</a> </li>
                    <li><a href="contact-us.html">Contact</a> </li>
                    <li class="login" data-toggle="modal" data-target="#myModal"><a href="#">Login</a> </li>
                  </ul>-->
                </div>
            </div>
        </div>
    </header>
</section>


<?php echo $__env->yieldContent('content'); ?>

<footer class="footer">
    <div class="container">
        <div class="footer-link">
            <ul>
                <li><a href="http://guptaclinic.in/dating/frontend/site/index.html">Home</a></li>
                <li><a href="http://guptaclinic.in/dating/frontend/site/profiles.html">Profile</a></li>
                <li><a href="http://guptaclinic.in/dating/frontend/site/stories.html">Stories</a></li>
                <li><a href="http://guptaclinic.in/dating/frontend/site/blog.html">Blog</a></li>
                <li><a href="http://guptaclinic.in/dating/frontend/site/about-us.html">About</a></li>
                <li><a href="http://guptaclinic.in/dating/frontend/site/contact-us.html">Contact</a></li>
            </ul>
        </div>
        <div class="col-md-offset-2 col-md-5 col-xs-12">
            <div class="copyright">© Copyright 2019. All rights reserved. Follow us</div>
        </div>
        <div class="col-md-4 col-xs-12">
            <div class="socail">
                <ul>
                    <li><a href="#" class="fb"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li><a href="#" class="tweet"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="#" class="gp"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                    <li><a href="#" class="pin"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                    <li><a href="#" class="insta"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<section id="app">
   <?php echo $__env->make('chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>

<script src="<?php echo e(asset('site/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('site/js/yii.js')); ?>"></script>
<script src="<?php echo e(asset('site/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('site/js/index.js')); ?>"></script>
<script src="<?php echo e(asset('site/js/bootstrap.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\layouts\site.blade.php ENDPATH**/ ?>