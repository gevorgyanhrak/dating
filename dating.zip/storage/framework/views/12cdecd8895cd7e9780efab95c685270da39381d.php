




<span id="auth_id"><?php echo e(auth::id()); ?></span>
<div id="app">
        <div class="col-sm-2 col-xs-12 chat_wrapper">
                <div class="col-inside-lg decor-default chat" style="overflow: hidden; outline: none;" tabindex="5000">
                        <div class="chat-users"><h6>Online</h6>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Auth::id() != $user->id): ?>
                                <div class="user_chat_item" data-name="<?php echo e($user->name); ?>" data-id="<?php echo e($user->id); ?>">
                                        <div class="avatar"><img src="https://bootdey.com/img/Content/avatar/avatar1.png"
                                                                 alt="User name">
                                                <div class="status <?php echo e($user->isOnline() ? 'online_us' : 'off'); ?>"></div>
                                        </div>
                                        <div class="name"><?php echo e($user->name); ?></div>
                                        <div class="mood">User mood</div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
        </div>

        <div ref="container" class="bottom_chat">

                <?php echo $__env->make('chat-item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
</div>
<?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views/chat.blade.php ENDPATH**/ ?>