<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top:150px;">
        <div class="row">
            <?php if(count($users) == 0): ?>
                <h1>Nothing</h1>
            <?php else: ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card-container">
                            <span class="pro">PRO</span>
                            <div class="img_wrap">
                            <img src="site/img/1.png" class="img-responsive" alt="user"/>
                            </div>
                            <h3><?php echo e($user->name); ?></h3>
                            <h6>Nodia, U.P.</h6>
                            <p>Age - <?php echo e($user->age); ?></p>
                            <div class="buttons">
                                <button class="primary">
                                    Message
                                </button>
                                <button class="primary ghost">
                                    Following
                                </button>
                            </div>
                            <div class="skills">
                                <h6>Info</h6>
                                <ul>
                                    <li>Age - <?php echo e($user->age); ?></li>
                                    <li>Gender - <?php if($user->gender == 1): ?> Male <?php else: ?> Female <?php endif; ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\search.blade.php ENDPATH**/ ?>