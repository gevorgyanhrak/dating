<?php $__env->startSection('content'); ?>
        <chats></chats>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\oldchat.blade.php ENDPATH**/ ?>