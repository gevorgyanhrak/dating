<?php $__env->startSection('content'); ?>
asfsa
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\admin\index.blade.php ENDPATH**/ ?>