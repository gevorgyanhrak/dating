<div id="app">>
        <div class="col-sm-2 col-xs-12 chat_wrapper">
                <div class="col-inside-lg decor-default chat" style="overflow: hidden; outline: none;" tabindex="5000">
                        <div class="chat-users"><h6>Online</h6>
                                <div class="user_chat_item">
                                        <div class="avatar"><img src="https://bootdey.com/img/Content/avatar/avatar1.png"
                                                                 alt="User name">
                                                <div class="status off"></div>
                                        </div>
                                        <div class="name">Admin</div>
                                        <div class="mood">User mood</div>
                                </div>
                        </div>
                </div>
        </div>

        <div ref="container" class="bottom_chat">

                <div class="col-md-3 pull-right border_chat">
                        <a class="btn_width custom_btn" data-toggle="collapse" role="button" aria-expanded="false"
                           aria-controls="multiCollapseExample1">Admin</a>
                        <span class="times_close_tab">&times;</span>

                        <div class="collapse multi-collapse">
                                <div class="card card-body cart_padding">
                                        <ul class="list-unstyled" style="height:300px; overflow-y:scroll">


                                                <li class="p-2 form-group">
                                                        <strong>gh</strong>
                                                        <div class="incoming_msg">
                                                                <div class="incoming_msg_img"><img src="https://bootdey.com/img/Content/avatar/avatar1.png"
                                                                                                   alt="sunil"></div>
                                                                <div class="received_msg">
                                                                        <div class="received_withd_msg">
                                                                                <p></p>
                                                                                <span class="time_date"> </span></div>
                                                                </div>

                                                        </div>
                                                </li>
                                        </ul>
                                        <form>
                                                <div class="message_box">

                                                        <input type="text" class="chat_input form-control1">
                                                        <button class="btn btn-primary btn_send_msg" ><i class="fa fa-paper-plane"
                                                                                                                                                 aria-hidden="true"></i></button>

                                                </div>
                                        </form>
                                </div>
                        </div>
                </div>

        </div>
</div>
<?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\chat.blade.php ENDPATH**/ ?>