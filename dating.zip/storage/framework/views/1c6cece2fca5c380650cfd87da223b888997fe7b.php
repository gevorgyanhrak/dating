<?php $__env->startSection('content'); ?>
    <div class="container"  style="margin-top:150px;">
        <h1>Welcome <?php echo e($user->name); ?></h1>

        <form method="post" action="<?php echo e(url('profile')); ?>/<?php echo e($user->id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group col-md-3">
                <label>Name</label>
                <input name="name" class="form-control" value="<?php echo e($user->name); ?>">
            </div>
            <div class="form-group col-md-3">
                <label>Email Address</label>
                <input name="email" class="form-control" value="<?php echo e($user->email); ?>">
            </div>
            <div class="form-group col-md-3">
                <label>Age</label>
                <input name="age" class="form-control" value="<?php echo e($user->age); ?>">
            </div>
            <div class="form-group col-md-3">
                <label>Gender</label>
                <select name="gender" class="form-control">
                    <option <?php if($user->gender == 1): ?> selected <?php endif; ?> value="1">Male</option>
                    <option <?php if($user->gender == 2): ?> selected <?php endif; ?> value="2">Female</option>
                </select>
            </div>
            <div class="form-group col-md-3">
                <input type="submit" value="Save" class="btn btn-primary">
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\user\edit.blade.php ENDPATH**/ ?>