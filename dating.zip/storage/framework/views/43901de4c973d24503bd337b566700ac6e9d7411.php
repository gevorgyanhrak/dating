<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\Users\User\Desktop\OSPanel\domains\dating\resources\views\layouts\dashboard.blade.php ENDPATH**/ ?>