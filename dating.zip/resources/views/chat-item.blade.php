<div class="col-md-3 pull-right border_chat chat_example" style="display: none">
    <a class="btn_width custom_btn" data-toggle="collapse" href="" role="button" aria-expanded="false"
       aria-controls="multiCollapseExample1">Example</a>
    <span class="times_close_tab">&times;</span>

    <div class="collapse multi-collapse" id="">
        <div class="card card-body cart_padding">
            <ul class="list-unstyled" style="height:300px; overflow-y:scroll">
            </ul>
            <form class="frmChat">
                <div class="message_box">

                    <input type="text" class="chat_input form-control1">
                    <button class="btn btn-primary btn_send_msg" ><i class="fa fa-paper-plane"
                                                                     aria-hidden="true"></i></button>

                </div>
            </form>
        </div>
    </div>
</div>
